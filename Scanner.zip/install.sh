echo "Coded By @E_L_F_6_6_6" 
echo "My Channel https://T.Me/Elf_Security_Cyber" 
cp -r Scanner /usr/local/bin
chmod 777 /usr/local/bin/Scanner
echo "Run Coomand Scanner"
