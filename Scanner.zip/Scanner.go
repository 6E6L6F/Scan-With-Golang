package main

import (
	"context"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"time"
	"github.com/Ullaakut/nmap"
	"github.com/fatih/color"
)

type IP struct {
	ip   string
	port string
}


func main(){
	Nmap()

}
func clear() {
	cmd := exec.Command("clear")
	cmd.Stderr = os.Stderr
	cmd.Stdout = os.Stdout
	cmd.Run()
}
func Nmap() {
	clear()
	data := IP{}
	PRINT := color.New(color.FgCyan).Add(color.BgHiGreen, color.Underline)
	print := color.New(color.FgRed)
	p2 := color.New(color.FgHiMagenta)
	p1 := color.New(color.FgHiBlue).Add(color.Underline)
	print.Printf("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n┣┫")
	p1.Printf("  Https://T.me/ELF_Securty_Cyber  ")
	print.Printf("┣┫\n┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n")
	PRINT.Printf("Enter The Ip Range : ")
	fmt.Scanln(&data.ip)
	PRINT.Printf("Enter The Port Range : ")
	fmt.Scanln(&data.port)
	clear()
	print.Println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	ctx, can := context.WithTimeout(context.Background(), 1*time.Minute)
	defer can()
	scanner, Ero := nmap.NewScanner(
		nmap.WithTargets(data.ip),
		nmap.WithPorts(data.port),
		nmap.WithContext(ctx),
	)
	if Ero != nil {
		log.Fatalf("Error %v\n", Ero)
	}
	res, War, ero := scanner.Run()
	if ero != nil {
		log.Fatalf("Error : %v\n", ero)
	}
	if War != nil {
		log.Fatalf("Warning : %v\n", War)
	}

	for _, host := range res.Hosts {
		if len(host.Ports) == 0 || len(host.Addresses) == 0 {
			continue
		}
		p2.Printf("IP : ")
		p1.Printf("%v\n", host.Addresses[0])
		if len(host.Addresses) > 1 {
			p2.Printf("Mac : ")
			p1.Printf("%v\n", host.Addresses[1])

		}
		for _, port := range host.Ports {
			p2.Printf("PORT : ")
			p1.Printf("%v %v %v %v\n", port.ID, port.Protocol, port.Service.Name, port.State)
		}
		print.Println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

	}

}
